<?php global $wpdb;

$table = $wpdb->prefix.'main_calc';
$poroshok = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'poroshok'" );
$ecsclus = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'ecsclus'" );
$almaz = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'almaz'" );
$litoy = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'litoy'" );
$stamp = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'stamp'" );
$R13 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R13'" );

$R14 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R14'" );
$R15 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R15'" );
$R16 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R16'" );
$R17 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R17'" );
$R18 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R18'" );
$R19 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R19'" );
$R20 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R20'" );
$R21 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R21'" );
$R22 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R22'" );
$R23 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R23'" );
$R24 = $wpdb->get_var( "SELECT value FROM $table WHERE key_ = 'R24'" );

?>

<div class="wrap">
	<h2><?php echo get_admin_page_title() ?></h2>
	<form action="<?php echo plugins_url('pitstop-core'); ?>/controllers/CalcController.php" method="POST">
		<h3>Вид покраски</h3>
		<div class="options">
		    <p>
		        <label>Порошковая покраска</label>
		        <br />
		        <input type="text" name="poroshok" placeholder="500" value="<?php echo $poroshok; ?>" />
		    </p>
	    </div>

	    <div class="options">
		    <p>
		        <label>Порошковая покраска "Эксклюзив"</label>
		        <br />
		        <input type="text" name="ecsclus" placeholder="500" value="<?php echo $ecsclus; ?>" />
		    </p>
	    </div>

	    <div class="options">
		    <p>
		        <label>Алмазная шлифовка</label>
		        <br />
		        <input type="text" name="almaz" placeholder="500" value="<?php echo $almaz; ?>" />
		    </p>
	    </div>


	    <h3>Тип диска</h3>
	    <div class="options">
		    <p>
		        <label>Литой</label>
		        <br />
		        <input type="text" name="litoy" placeholder="500" value="<?php echo $litoy; ?>" />
		    </p>
	    </div>

	    <div class="options">
		    <p>
		        <label>Штампованный</label>
		        <br />
		        <input type="text" name="stamp" placeholder="500" value="<?php echo $stamp; ?>" />
		    </p>
	    </div>

	    <h3>Радиус диска</h3>
	    <div class="options">
		    <p>
		        <label>R13</label>
		        <br />
		        <input type="text" name="R13" placeholder="500" value="<?php echo $R13; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R14</label>
		        <br />
		        <input type="text" name="R14" placeholder="500" value="<?php echo $R14; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R15</label>
		        <br />
		        <input type="text" name="R15" placeholder="500" value="<?php echo $R15; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R16</label>
		        <br />
		        <input type="text" name="R16" placeholder="500" value="<?php echo $R16; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R17</label>
		        <br />
		        <input type="text" name="R17" placeholder="500" value="<?php echo $R17; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R18</label>
		        <br />
		        <input type="text" name="R18" placeholder="500" value="<?php echo $R18; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R19</label>
		        <br />
		        <input type="text" name="R19" placeholder="500" value="<?php echo $R19; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R20</label>
		        <br />
		        <input type="text" name="R20" placeholder="500" value="<?php echo $R20; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R21</label>
		        <br />
		        <input type="text" name="R21" placeholder="500" value="<?php echo $R21; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R22</label>
		        <br />
		        <input type="text" name="R22" placeholder="500" value="<?php echo $R22; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R23</label>
		        <br />
		        <input type="text" name="R23" placeholder="500" value="<?php echo $R23; ?>" />
		    </p>
	    </div>
	    <div class="options">
		    <p>
		        <label>R24</label>
		        <br />
		        <input type="text" name="R24" placeholder="500" value="<?php echo $R24; ?>" />
		    </p>
	    </div>

	    <button type="submit" class="button action">Сохранить</button>
    </form>	
</div>