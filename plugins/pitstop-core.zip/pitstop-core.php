<?php
/*
 * Plugin Name: Pitstop Core plugin
 */
include plugin_dir_path(__FILE__) . 'inc/functions.php';