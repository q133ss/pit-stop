<?php
global $wpdb, $table_prefix;

if(!isset($wpdb))
{
    require_once('../../../../wp-config.php');
    require_once('../../../../wp-includes/wp-db.php');
}

	//If table not exists, that create
	$table_name = $wpdb->prefix . 'main_calc';
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  key_ varchar(255) NOT NULL UNIQUE,
	  value varchar(55) DEFAULT '' NOT NULL,
	  PRIMARY KEY  (id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	//Update or create new post

$result1 = $wpdb->update($table_name, [ 'key_' => 'poroshok', 'value' => $_POST['poroshok'] ], array('key_' => 'poroshok'));
//If nothing found to update, it will try and create the record.
// if ($result1 === FALSE || $result1 < 1) {
//     $wpdb->insert($table_name, [ 'key_' => 'poroshok', 'value' => $_POST['poroshok'] ]);
// }

$result = $wpdb->update($table_name, [ 'key_' => 'ecsclus', 'value' => $_POST['ecsclus'] ], array('key_' => 'ecsclus'));
//If nothing found to update, it will try and create the record.
// if ($result === FALSE || $result < 1) {
//     $wpdb->insert($table_name, [ 'key_' => 'ecsclus', 'value' => $_POST['ecsclus'] ]);
// }

$result = $wpdb->update($table_name, [ 'key_' => 'almaz', 'value' => $_POST['almaz'] ], array('key_' => 'almaz'));
// if ($result === FALSE || $result < 1) {
//     $wpdb->insert($table_name, [ 'key_' => 'almaz', 'value' => $_POST['almaz'] ]);
// }

$result = $wpdb->update($table_name, [ 'key_' => 'litoy', 'value' => $_POST['litoy'] ], array('key_' => 'litoy'));
// if ($result === FALSE || $result < 1) {
//     $wpdb->insert($table_name, [ 'key_' => 'litoy', 'value' => $_POST['litoy'] ]);
// }


$result = $wpdb->update($table_name, [ 'key_' => 'stamp', 'value' => $_POST['stamp'] ], array('key_' => 'stamp'));
// if ($result === FALSE || $result < 1) {
//     $wpdb->insert($table_name, [ 'key_' => 'stamp', 'value' => $_POST['stamp'] ]);
// }


for($i = 13; $i<25; $i++){
	$result = $wpdb->update($table_name, [ 'key_' => 'R'.$i, 'value' => $_POST['R'.$i] ], array('key_' => 'R'.$i));
	// if ($result === FALSE || $result < 1) {
	//     $wpdb->insert($table_name, [ 'key_' => 'R'.$i, 'value' => $_POST['R'.$i] ]);
	// }
}

header("location:javascript://history.go(-1)");