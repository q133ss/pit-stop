<?php
add_action('init', 'uslugi');
function uslugi(){
	//Услуги пост
    register_post_type('uslugi', array(
        'labels'             => array(
            'name'               => 'Услуги', // Основное название типа записи
            'singular_name'      => 'услуга', // отдельное название записи типа Book
            'add_new'            => 'Добавить услугу',
            'add_new_item'       => 'Добавить услугу',
            'edit_item'          => 'Редактировать услугу',
            'new_item'           => 'Новая услуга',
            'view_item'          => 'Посмотреть услугу',
            'search_items'       => 'Найти услугу',
            'not_found'          => 'Ничего не найдено',
            'not_found_in_trash' => 'В корзине ничего не найдено',
            'parent_item_colon'  => '',
            'menu_name'          => 'Услуги'

          ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => true,
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title','thumbnail','excerpt')
    ) );


    //Услуги таксономия
    register_taxonomy( 'taxonomy', [ 'uslugi' ], [
		'label'                 => '', // определяется параметром $labels->name
		'labels'                => [
			'name'              => 'Категория',
			'singular_name'     => 'Категория',
			'search_items'      => 'Поиск категорий',
			'all_items'         => 'Все категории',
			'view_item '        => 'Смотреть категорию',
			'parent_item'       => 'Родительская категория',
			'parent_item_colon' => 'Parent Genre:',
			'edit_item'         => 'Редактировать категорию',
			'update_item'       => 'Обновить категорию',
			'add_new_item'      => 'Добавить новую категорию',
			'new_item_name'     => 'Имя новой категории',
			'menu_name'         => 'Категории',
		],
		'description'           => '', // описание таксономии
		'public'                => true,
		'hierarchical'          => true,
		'rewrite'               => true,
		//'query_var'             => $taxonomy, // название параметра запроса
		'capabilities'          => array(),
		'meta_box_cb'           => null, // html метабокса. callback: `post_categories_meta_box` или `post_tags_meta_box`. false — метабокс отключен.
		'show_admin_column'     => false, // авто-создание колонки таксы в таблице ассоциированного типа записи. (с версии 3.5)
		'show_in_rest'          => null, // добавить в REST API
		'rest_base'             => null, // $taxonomy
	] );
}


add_action('init', 'custom_posts');
function custom_posts(){
	//Примеры наших работ
	register_post_type('our_work', array(
        'labels'             => array(
            'name'               => 'Наши работы', // Основное название типа записи
            'singular_name'      => 'работа', // отдельное название записи типа Book
            'add_new'            => 'Добавить работу',
            'add_new_item'       => 'Добавить работу',
            'edit_item'          => 'Редактировать работу',
            'new_item'           => 'Новая работа',
            'view_item'          => 'Посмотреть работу',
            'search_items'       => 'Найти работу',
            'not_found'          => 'Ничего не найдено',
            'not_found_in_trash' => 'В корзине ничего не найдено',
            'parent_item_colon'  => '',
            'menu_name'          => 'Наши работы'
          ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => true,
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('thumbnail')
    ) );

    //Услуги таксономия
    register_taxonomy( 'cats', [ 'our_work' ], [
		'label'                 => '', // определяется параметром $labels->name
		'labels'                => [
			'name'              => 'Категория',
			'singular_name'     => 'Категория',
			'search_items'      => 'Поиск категорий',
			'all_items'         => 'Все категории',
			'view_item '        => 'Смотреть категорию',
			'parent_item'       => 'Родительская категория',
			'parent_item_colon' => 'Parent Genre:',
			'edit_item'         => 'Редактировать категорию',
			'update_item'       => 'Обновить категорию',
			'add_new_item'      => 'Добавить новую категорию',
			'new_item_name'     => 'Имя новой категории',
			'menu_name'         => 'Категории',
		],
		'description'           => '', // описание таксономии
		'public'                => true,
		'hierarchical'          => true,
		'rewrite'               => true,
		//'query_var'             => $taxonomy, // название параметра запроса
		'capabilities'          => array(),
		'meta_box_cb'           => null, // html метабокса. callback: `post_categories_meta_box` или `post_tags_meta_box`. false — метабокс отключен.
		'show_admin_column'     => false, // авто-создание колонки таксы в таблице ассоциированного типа записи. (с версии 3.5)
		'show_in_rest'          => null, // добавить в REST API
		'rest_base'             => null, // $taxonomy
	] );

}